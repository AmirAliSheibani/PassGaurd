# PassGuard template map

All page templates should extend `base.html` and reuse the shared partials instead of reimplementing navigation, form errors, buttons, empty states, or confirmation actions.

## Existing / planned page templates

### `core`
- `core/home.html` — dashboard / workspace landing page. Match the final filename to the actual `core` view's `template_name` before creating it; the current local code may still use its temporary test template.

### `user_app`
- `user_app/login.html`
- `user_app/register.html`
- `user_app/backup_code_setup.html`
- `user_app/backup_code_recovery.html`
- `user_app/reset_master_password.html`
- `user_app/regenerate_backup_codes.html`

### `vault_app`
- `vault_app/vault_list.html`
- `vault_app/vault_detail.html`
- `vault_app/vault_form.html` — shared create / update form
- `vault_app/vault_confirm_delete.html`
- `vault_app/category_list.html`
- `vault_app/category_form.html` — shared create / update form
- `vault_app/category_confirm_delete.html`

### `credential_app`
- `credential_app/credential_list.html`
- `credential_app/credential_form.html` — shared create / update form
- `credential_app/credential_detail.html`
- `credential_app/credential_confirm_delete.html`
- `credential_app/credential_rotate_password.html`
- `credential_app/credential_move_to_vault.html`

## Shared UI partials

- `_page_header.html`
- `_messages.html`
- `_form_errors.html`
- `_form_field.html`
- `_form_fields.html`
- `_form_card_header.html`
- `_confirm_actions.html`
- `_empty_state.html`
- `_stat_card.html`
- `_vault_card.html`
- `_category_chip.html`
- `_credential_row.html`
- `_password_value.html`
- `_backup_code_grid.html`
- `_sidebar.html`
- `_topbar.html`
- `_icon.html` / `_icon_sprite.html`

## Recommended view context

Set `page_title`, `page_description`, and `active_nav` in each view. Set `vault` only after the existing owner-scoped selector successfully resolves the requested Vault. The shared navigation context processor exposes `sidebar_vaults` and `sidebar_vault_count` for the sidebar.

## Example form page

```django
{% extends "base.html" %}
{% block title %}Add credential{% endblock %}
{% block content %}
  {% include "partials/_page_header.html" with kicker="Credential" heading="Add credential" description="Save the sign-in details for a service." %}
  <section class="form-card">
    {% include "partials/_form_card_header.html" with heading="Account details" description="Fields are validated by the existing Django form." %}
    <div class="form-card-body">
      <form method="post" novalidate>
        {% csrf_token %}
        {% include "partials/_form_fields.html" with form=form allow_password_generation=True %}
        {% include "partials/_confirm_actions.html" with cancel_url=cancel_url submit_label="Save credential" %}
      </form>
    </div>
  </section>
{% endblock %}
```

Do not apply `allow_password_generation=True` to Master Password or account recovery forms. The generator is intended for stored service credentials.
