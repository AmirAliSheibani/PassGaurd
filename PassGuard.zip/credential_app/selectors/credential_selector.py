from django.db.models import Q, QuerySet
from credential_app.models import Credential
from vault_app.models import Vault


class CredentialSelector:

    @classmethod
    def get_by_id(cls, credential_id: int) -> Credential:
        return Credential.objects.select_related(
            "vault",
            "vault__user",
            "category",
        ).get(pk=credential_id)

    @classmethod
    def get_by_id_for_user(cls, credential_id: int, user_id: int) -> Credential:
        return Credential.objects.select_related(
            "vault",
            "vault__user",
            "category",
        ).get(pk=credential_id, vault__user_id=user_id)

    @classmethod
    def get_by_vault(cls, *, vault: Vault):
        return (
            Credential.objects.filter(vault=vault)
            .select_related(
                "category",
            )
        )

    @classmethod
    def get_favorites(cls, vault: Vault):
        return Credential.objects.filter(vault=vault, is_favorite=True)

    @classmethod
    def search(
            cls,
            *,
            vault: Vault,
            user_id: int,
            query: str,
    ) -> QuerySet[Credential]:
        """
        Search credentials within a specific vault owned by the user.
        """

        queryset = Credential.objects.filter(
            vault_id=vault.pk,
            vault__user_id=user_id,
        ).select_related(
            "category",
        )

        query = query.strip()

        if not query:
            return queryset

        return queryset.filter(
            Q(service_name__icontains=query)
            | Q(service_url__icontains=query)
            | Q(login_username__icontains=query)
            | Q(login_email__icontains=query)
            | Q(category__name__icontains=query)
        )

    @classmethod
    def exists_by_name(cls, *, vault:Vault, service_name:str) -> bool:
        return Credential.objects.filter(
            vault=vault,
            service_name=service_name,
        ).exists()

    @classmethod
    def count(cls, vault:Vault) -> int:
        return Credential.objects.filter(vault=vault).count()

    @classmethod
    def get_recent(cls, vault: Vault):
        return Credential.objects.filter(vault=vault).order_by("-updated_at")



