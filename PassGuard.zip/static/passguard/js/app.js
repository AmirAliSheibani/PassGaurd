(function () {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  function showToast(message, type = "success") {
    const region = $("[data-toast-region]");
    if (!region) return;

    const toast = document.createElement("div");
    toast.className = `toast${type === "error" ? " is-error" : ""}`;
    toast.setAttribute("role", type === "error" ? "alert" : "status");

    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    icon.setAttribute("class", "icon");
    icon.setAttribute("aria-hidden", "true");
    const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
    use.setAttribute("href", type === "error" ? "#icon-alert-triangle" : "#icon-check-circle");
    icon.appendChild(use);

    const text = document.createElement("span");
    text.textContent = message;
    toast.append(icon, text);
    region.appendChild(toast);

    window.setTimeout(() => {
      toast.classList.add("is-leaving");
      window.setTimeout(() => toast.remove(), 180);
    }, 2800);
  }

  function setupSidebar() {
    const sidebar = $("#appSidebar");
    const openButton = $("[data-sidebar-open]");
    const scrims = $$('[data-sidebar-close]');
    if (!sidebar || !openButton) return;

    const closeButtons = $$('[data-sidebar-close]');
    function open() {
      sidebar.classList.add("is-open");
      document.body.classList.add("sidebar-open");
      openButton.setAttribute("aria-expanded", "true");
      closeButtons.forEach((element) => {
        if (element.classList.contains("mobile-scrim")) element.hidden = false;
      });
      const firstLink = $("a, button", sidebar);
      if (firstLink) firstLink.focus({ preventScroll: true });
    }
    function close() {
      sidebar.classList.remove("is-open");
      document.body.classList.remove("sidebar-open");
      openButton.setAttribute("aria-expanded", "false");
      closeButtons.forEach((element) => {
        if (element.classList.contains("mobile-scrim")) element.hidden = true;
      });
      openButton.focus({ preventScroll: true });
    }

    openButton.addEventListener("click", () => {
      if (sidebar.classList.contains("is-open")) close();
      else open();
    });
    scrims.forEach((element) => element.addEventListener("click", close));
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && sidebar.classList.contains("is-open")) close();
    });
    window.addEventListener("resize", () => {
      if (window.innerWidth > 820 && sidebar.classList.contains("is-open")) {
        sidebar.classList.remove("is-open");
        document.body.classList.remove("sidebar-open");
        openButton.setAttribute("aria-expanded", "false");
        closeButtons.forEach((element) => {
          if (element.classList.contains("mobile-scrim")) element.hidden = true;
        });
      }
    });
  }

  function setupMessageDismissal() {
    document.addEventListener("click", (event) => {
      const button = event.target.closest("[data-dismiss-message]");
      if (!button) return;
      const alert = button.closest(".alert");
      if (alert) alert.remove();
    });
  }

  function setupPasswordVisibility() {
    document.addEventListener("click", (event) => {
      const button = event.target.closest("[data-password-toggle]");
      if (!button) return;
      const input = document.getElementById(button.dataset.passwordToggle);
      if (!input) return;

      const reveal = input.type === "password";
      input.type = reveal ? "text" : "password";
      button.setAttribute("aria-pressed", String(reveal));
      button.setAttribute("aria-label", `${reveal ? "Hide" : "Show"} ${button.getAttribute("aria-label").replace(/^(Show|Hide) /, "")}`);
      const use = $("use", button);
      if (use) use.setAttribute("href", reveal ? "#icon-eye-off" : "#icon-eye");
    });
  }

  // Use rejection sampling rather than byte % alphabet.length to avoid modulo bias.
  function secureIndex(max) {
    const limit = Math.floor(256 / max) * max;
    const byte = new Uint8Array(1);
    do {
      window.crypto.getRandomValues(byte);
    } while (byte[0] >= limit);
    return byte[0] % max;
  }

  function secureCharacter(alphabet) {
    return alphabet[secureIndex(alphabet.length)];
  }

  function shuffleSecurely(items) {
    for (let index = items.length - 1; index > 0; index -= 1) {
      const swapIndex = secureIndex(index + 1);
      [items[index], items[swapIndex]] = [items[swapIndex], items[index]];
    }
    return items;
  }

  function generatePassword(length = 20) {
    const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const lower = "abcdefghijklmnopqrstuvwxyz";
    const digits = "0123456789";
    const symbols = "!@#$%^&*_-+=.";
    const alphabet = upper + lower + digits + symbols;
    const output = [
      secureCharacter(upper),
      secureCharacter(lower),
      secureCharacter(digits),
      secureCharacter(symbols),
    ];
    while (output.length < length) output.push(secureCharacter(alphabet));
    return shuffleSecurely(output).join("");
  }

  function setupPasswordGenerator() {
    document.addEventListener("click", (event) => {
      const button = event.target.closest("[data-generate-password-for]");
      if (!button) return;
      const input = document.getElementById(button.dataset.generatePasswordFor);
      if (!input) return;

      if (!window.crypto || typeof window.crypto.getRandomValues !== "function") {
        showToast("Secure password generation is not supported in this browser context.", "error");
        return;
      }

      const requestedLength = Number(button.dataset.passwordLength || 20);
      const length = Number.isInteger(requestedLength) ? Math.max(16, Math.min(requestedLength, 128)) : 20;
      input.value = generatePassword(length);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      input.focus({ preventScroll: true });
      showToast("Secure password generated. Save the form to store it.");
    });
  }

  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const helper = document.createElement("textarea");
    helper.value = text;
    helper.setAttribute("readonly", "readonly");
    helper.style.position = "fixed";
    helper.style.opacity = "0";
    document.body.appendChild(helper);
    helper.select();
    const succeeded = document.execCommand("copy");
    helper.remove();
    if (!succeeded) throw new Error("Clipboard unavailable");
  }

  function setupCopyButtons() {
    document.addEventListener("click", async (event) => {
      const button = event.target.closest("[data-copy-target]");
      if (!button) return;
      const target = document.getElementById(button.dataset.copyTarget);
      if (!target) return;
      const text = "value" in target ? target.value : target.textContent;
      if (!text) {
        showToast("There is nothing to copy.", "error");
        return;
      }
      try {
        await copyText(text);
        showToast(button.dataset.copySuccess || "Copied to clipboard.");
      } catch (_error) {
        showToast("Could not access the clipboard. Select and copy manually.", "error");
      }
    });
  }

  function getBackupCodes(button) {
    const section = button.closest(".backup-code-section");
    if (!section) return [];
    return $$(".backup-code code", section).map((node) => node.textContent.trim()).filter(Boolean);
  }

  function setupBackupCodeActions() {
    document.addEventListener("click", async (event) => {
      const copyButton = event.target.closest("[data-copy-backup-codes]");
      const downloadButton = event.target.closest("[data-download-backup-codes]");
      const button = copyButton || downloadButton;
      if (!button) return;

      const codes = getBackupCodes(button);
      if (!codes.length) {
        showToast("No backup codes are available to export.", "error");
        return;
      }
      const content = [
        "PassGuard backup codes",
        "Each code can be used once. Store this file somewhere safe and offline.",
        "",
        ...codes,
        "",
      ].join("\n");

      if (copyButton) {
        try {
          await copyText(content);
          showToast("Backup codes copied. Store them securely.");
        } catch (_error) {
          showToast("Could not access the clipboard. Use the download option.", "error");
        }
        return;
      }

      const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = "passguard-backup-codes.txt";
      link.hidden = true;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
      showToast("Backup codes downloaded. Keep the file private.");
    });
  }

  function setupConfirmations() {
    document.addEventListener("submit", (event) => {
      const form = event.target;
      if (!(form instanceof HTMLFormElement)) return;
      const submitter = event.submitter;
      const prompt = (submitter && submitter.dataset.confirm) || form.dataset.confirm;
      if (prompt && !window.confirm(prompt)) event.preventDefault();
    });
  }

  function setupSearchShortcut() {
    document.addEventListener("keydown", (event) => {
      const target = event.target;
      const typing = target instanceof HTMLElement && (
        target.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)
      );
      if (typing || event.altKey || event.ctrlKey || event.metaKey) return;
      if (event.key === "/") {
        const search = $(".topbar-search input[type='search']");
        if (search) {
          event.preventDefault();
          search.focus();
        }
      }
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    setupSidebar();
    setupMessageDismissal();
    setupPasswordVisibility();
    setupPasswordGenerator();
    setupCopyButtons();
    setupBackupCodeActions();
    setupConfirmations();
    setupSearchShortcut();
  });
})();
